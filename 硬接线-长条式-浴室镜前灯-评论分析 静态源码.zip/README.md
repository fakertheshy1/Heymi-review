# 硬接线-集成式-长条式 评论分析

这是可独立构建的静态 Dashboard 源码，评论数据位于 `src/review-data.json`。

## 本地运行

```bash
npm install
npm run dev
```

## 生成静态文件

```bash
npm run build
```

构建结果位于 `dist/`。项目已使用相对资源路径，可部署到任意静态网站托管目录。
